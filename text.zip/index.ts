import gsap from "gsap";
const p = document.createElement("p");
p.innerText =
  "SplitText makes it easy to break apart the text in an HTML element so that each character, word, and/or line is wrapped in its own div tag.";
document.body.appendChild(p);

if (p) {
  const chars = p.innerText.split(""); // 글자 단위로 나눔
  p.innerHTML = chars.map((char) => `<span>${char}</span>`).join("");

  gsap.fromTo(
    "span",
    { opacity: 0 },
    { opacity: 1, duration: 0.5, stagger: 0.1 }
  );
}