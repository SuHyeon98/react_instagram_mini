import { gsap } from "gsap";

gsap.registerPlugin(ScrollTrigger);

//
const tl = gsap.timeline({
  scrollTrigger: {
    trigger: "section",
    start: "top top", 
    end: "+=2000",
    scrub: 1, 
    pin: true,
    markers: true,
  },
})

tl.fromTo(".textImage", { opacity: 0 }, { opacity: 1, duration: 1 }).fromTo(
    ".textImage",
    {},
    { opacity: 0, duration: 1 },
    "+=1"
  );
