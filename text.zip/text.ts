import { gsap } from "gsap";

const tl = gsap.timeline();

//replaces yourElement's text with "This is the new text" 
tl.to('.textImage', {
    duration: 5,

    scrollTrigger: {
      trigger: '.section',
      start: 'top top',
      end: '+=5000',
      scrub: true,
      markers: true,
      pin: '.section',
    },
});
